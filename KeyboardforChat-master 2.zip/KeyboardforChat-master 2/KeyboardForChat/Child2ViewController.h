//
//  Child2ViewController.h
//  KeyboardForChat
//
//  Created by ruofei on 16/4/8.
//  Copyright © 2016年 ruofei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Child2ViewController : UIViewController

@end
