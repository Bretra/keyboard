//
//  NSString+Emoji.h
//  KeyboardForChat
//
//  Created by ruofei on 16/5/16.
//  Copyright © 2016年 ruofei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Emoji)

- (BOOL)isEmoji;

@end
