//
//  DefultViewController.m
//  KeyboardForChat
//
//  Created by YongLeiChu on 2018/10/1.
//  Copyright © 2018年 ruofei. All rights reserved.
//

#import "DefultViewController.h"

#import "ChatKeyBoard.h"

@interface DefultViewController ()

@end

@implementation DefultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    ChatKeyBoard *keyBoard = [[ChatKeyBoard alloc] initWithFrame:CGRectMake(0, kScreenHeight - 34, kScreenWidth, 49 + 34)];
    [self.view addSubview:keyBoard];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
